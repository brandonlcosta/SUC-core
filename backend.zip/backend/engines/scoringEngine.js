// File: backend/engines/scoringEngine.js
// Scoring Engine — trust-priority scoring & leaderboard management

const PRIORITY_ORDER = {
  truth: 3,
  soft: 2,
  projection: 1,
};

const state = {
  runners: {},
};

/**
 * Update scoring state based on an event.
 * Applies trust priority (truth > soft > projection).
 * @param {Object} event
 */
export function updateScoring(event) {
  const { runner_id, event_type, quality } = event;
  if (!runner_id) return;

  if (!state.runners[runner_id]) {
    state.runners[runner_id] = { laps: 0, last_event: null };
  }

  const runner = state.runners[runner_id];
  const incomingPriority = PRIORITY_ORDER[quality?.trust_level] || 0;
  const currentPriority = runner.last_event
    ? PRIORITY_ORDER[runner.last_event.quality?.trust_level]
    : 0;

  // Only update if higher or equal priority
  if (incomingPriority >= currentPriority) {
    if (event_type === "lap_completed") {
      runner.laps += 1;
    }
    runner.last_event = event;
  }
}

/**
 * Get leaderboard snapshot
 * @returns {Array<{ runner_id: string, laps: number }>}
 */
export function getLeaderboard() {
  return Object.entries(state.runners).map(([id, data]) => ({
    runner_id: id,
    laps: data.laps,
  }));
}

/**
 * Reset scoring state
 */
export function resetScoring() {
  Object.keys(state.runners).forEach((k) => delete state.runners[k]);
}

// ✅ Default export for clean imports
export default {
  updateScoring,
  getLeaderboard,
  resetScoring,
};
